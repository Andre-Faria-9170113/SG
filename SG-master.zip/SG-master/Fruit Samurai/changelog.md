# TODO

- Lançar Bolas
  
  - Quantas e de quanto em quanto Tempo.
  - Tamanho = (2 < raio < 6)
  - Velocidade = ?
  - "Gravidade" = ?
  - Não deve haver mais que três bolas de cada vez em jogo.

- "Jogador" (Objeto)

  - Vidas = 3
  - Tirar Vidas
